from flask import Flask, render_template, request, redirect, session
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secret"


users = {
    "admin":{
        "password":"admin!",
        "name":"Administrator",
        "birthday":"1995-01-01",
        "address":"HQ",
        "phone":"000000",
        "role":"admin",
        "reports":[]
    }
}


@app.route("/")
def index():
    return render_template("index.html")


# reg
@app.route("/register", methods=["GET","POST"])
def register():

    error=None

    if request.method=="POST":

        username=request.form["username"]
        password=request.form["password"]
        name=request.form["name"]
        birthday=request.form["birthday"]
        address=request.form["address"]
        phone=request.form["phone"]

        special="!@#$%^&*()_+-=[]{}|;:,.<>?"

        if username in users:
            error="User already existing"

        elif len(password) <= 3:
            error="Password must be more than 3 characters"

        elif not any(char in special for char in password):
            error="Password must contain at least 1 special character"

        else:
            users[username]={
                "password":password,
                "name":name,
                "birthday":birthday,
                "address":address,
                "phone":phone,
                "role":"user",
                "reports":[]
            }
            return redirect("/login")

    return render_template("register.html", error=error)


# log
@app.route("/login", methods=["GET","POST"])
def login():

    error=None

    if request.method=="POST":

        username=request.form["username"]
        password=request.form["password"]

        if username in users and users[username]["password"]==password:

            session["user"]=username

            if users[username]["role"]=="admin":
                return redirect("/reports")

            # send regular users to a simple menu page
            return redirect("/menu")

        else:
            error="Incorrect username or password"

    return render_template("login.html", error=error)


# dashboard
@app.route("/dashboard", methods=["GET","POST"])
def dashboard():

    if "user" not in session:
        return redirect("/login")

    username=session["user"]

    # If the user in session was removed (e.g. server restarted), force login again
    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    if users[username]["role"]=="admin":
        return redirect("/reports")

    success=None
    error=None

    # show success messages passed via query string (e.g., after deleting)
    if request.method == "GET":
        success = request.args.get("success")

    if request.method=="POST":

        report=request.form["report"]

        if report.strip()=="":
            error="Report cannot be empty"
        else:
            time=datetime.now().strftime("%Y-%m-%d %I:%M %p")

            users[username]["reports"].append({
                "report":report,
                "time":time
            })

            success="Report submitted successfully!"

    return render_template(
        "dashboard.html",
        reports=users[username]["reports"],
        username=username,
        success=success,
        error=error
    )


# edit/update
@app.route("/edit/<int:index>", methods=["GET","POST"])
def edit(index):

    if "user" not in session:
        return redirect("/login")

    username=session["user"]

    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    report_data=users[username]["reports"][index]

    error=None
    success=None

    if request.method=="POST":

        new_report=request.form["report"]

        if new_report.strip() == "":
            error="Report cannot be empty"
        else:
            users[username]["reports"][index]["report"] = new_report
            success = "Report updated successfully!"
            return render_template(
                "dashboard.html",
                reports=users[username]["reports"],
                username=username,
                success=success,
                error=None
            )

    return render_template(
        "edit.html",
        report=report_data,
        index=index,
        error=error,
        success=success
    )


# admin pan
@app.route("/reports")
def reports():

    if "user" not in session:
        return redirect("/login")

    username=session["user"]

    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    if users[username]["role"]!="admin":
        return redirect("/dashboard")

    success=request.args.get("success")

    return render_template(
        "reports.html",
        users=users,
        username=username,
        success=success
    )


# DELETE WITH CONFIRMATION
@app.route("/delete_confirm/<username>/<int:index>")
def delete_confirm_admin(username, index):
    if "user" not in session:
        return redirect("/login")

    current = session["user"]

    if users[current]["role"] != "admin":
        return redirect("/dashboard")

    if username not in users or index >= len(users[username]["reports"]):
        return redirect("/reports")

    report = users[username]["reports"][index]
    return render_template("confirm_delete.html", target_username=username, index=index, report=report, admin=True)

@app.route("/delete/<username>/<int:index>", methods=["POST"])
def delete(username, index):
    if "user" not in session:
        return redirect("/login")

    current = session["user"]

    if users[current]["role"] == "admin":
        if username in users and index < len(users[username]["reports"]):
            users[username]["reports"].pop(index)
            success = "Report deleted successfully!"
            return render_template(
                "reports.html",
                users=users,
                username=current,
                success=success
            )

    return redirect("/reports")

@app.route("/delete_confirm_self/<int:index>")
def delete_confirm_self(index):
    if "user" not in session:
        return redirect("/login")

    username = session["user"]

    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    if index >= len(users[username]["reports"]):
        return redirect("/dashboard")

    report = users[username]["reports"][index]
    return render_template("confirm_delete.html", target_username=username, index=index, report=report, admin=False)

@app.route("/delete/<int:index>", methods=["POST"])
def delete_self(index):
    if "user" not in session:
        return redirect("/login")

    username = session["user"]

    # Allow the logged-in user to delete their own report by index
    if index < len(users[username]["reports"]):
        users[username]["reports"].pop(index)

    success = "Report deleted successfully!"
    return render_template(
        "dashboard.html",
        reports=users[username]["reports"],
        username=username,
        success=success,
        error=None
    )


# MENU (after login)
@app.route("/menu")
def menu():
    if "user" not in session:
        return redirect("/login")

    username = session["user"]
    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    # regular users should see the menu; admins go to reports
    if users[username]["role"]=="admin":
        return redirect("/reports")

    success = request.args.get("success")

    return render_template("menu.html", username=username, success=success)


# PROFILE (edit username and display name)
@app.route("/profile", methods=["GET","POST"])
def profile():
    if "user" not in session:
        return redirect("/login")

    username = session["user"]
    if username not in users:
        session.pop("user", None)
        return redirect("/login")

    error=None
    success=None

    if request.method=="POST":
        new_username = request.form.get("username").strip()
        birthday = request.form.get("birthday").strip()
        address = request.form.get("address").strip()
        phone = request.form.get("phone").strip()

        if not new_username:
            error = "Username cannot be empty"
        elif new_username != username and new_username in users:
            error = "Username already taken"
        else:
            # update username key if changed
            if new_username != username:
                users[new_username] = users.pop(username)
                username = new_username
                session["user"] = new_username

            # update profile fields
            users[username]["birthday"] = birthday
            users[username]["address"] = address
            users[username]["phone"] = phone

            success = "Profile updated successfully!"

    return render_template("profile.html", username=username, name=users[username].get("name",""), birthday=users[username].get("birthday",""), address=users[username].get("address",""), phone=users[username].get("phone",""), error=error, success=success)


@app.route("/logout")
def logout():
    session.pop("user",None)
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
